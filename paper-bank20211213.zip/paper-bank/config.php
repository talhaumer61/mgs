<?php

$_ENV["HOST"] = "localhost";
$_ENV["URLROOT"] = "https://mgs.gptech.pk/paper-bank";
$_ENV['LOGOUT_REDIRECT'] = "https://mgs.gptech.pk/login.php";
$_ENV["PARENTROOT"] = "https://mgs.gptech.pk";

$_ENV["HOST"] = 'localhost';
$_ENV["DBNAME"] = 'neotericschools_mgs2021';
$_ENV["USERNAME"] = 'neotericschools_mgs';
$_ENV["PASSWORD"] = 'uw#7P({9hx7z';
$_ENV["ENV"] = 'production';
$_ENV["DEFAULT_CONTROLLER"] = 'Dashboard';
$_ENV["DEFAULT_METHOD"] = 'index';
$_ENV['LIMIT'] = 10;
$_ENV['DBDRIVER'] = 'mysql';
$_ENV['SITENAME'] = "Paper Bank";
$_ENV['LONG_MARKS'] = 5;
$_ENV['SHORT_MARKS'] = 2;
$_ENV['MCQ_MARKS'] = 1;

