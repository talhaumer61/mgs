<?php

/**
 * This is the file that every request is routed through
 */

require("src/connector.php");

new Core(true);

