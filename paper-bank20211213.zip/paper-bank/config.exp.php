<?php

$_ENV["HOST"] = "localhost";
$_ENV["URLROOT"] = "http://localhost/FolderName";
$_ENV['LOGOUT_REDIRECT'] = "http://localhost/FolderName/routeName";
$_ENV["PARENTROOT"] = "https://parentUrl.com";

$_ENV["DBNAME"] = 'database_name';
$_ENV["USERNAME"] = 'root';
$_ENV["PASSWORD"] = '';
$_ENV["ENV"] = 'development';
$_ENV["DEFAULT_CONTROLLER"] = 'Dashboard';
$_ENV["DEFAULT_METHOD"] = 'index';
$_ENV['LIMIT'] = 10;
$_ENV['DBDRIVER'] = 'mysql';
$_ENV['SITENAME'] = "School Management System";
$_ENV['LONG_MARKS'] = 5;
$_ENV['SHORT_MARKS'] = 2;
$_ENV['MCQ_MARKS'] = 1;


