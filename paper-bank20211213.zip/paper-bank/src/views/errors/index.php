<?php
echo "404 Error page";